package main

func cfunc()

func main() {
	cfunc()
}
