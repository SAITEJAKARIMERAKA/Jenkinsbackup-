//go:build freebsd && amd64 && !cgo

// This file is used to detect building on freebsd with cgo disabled

package can_not_build_on_freebsd_with_cgo_disabled
